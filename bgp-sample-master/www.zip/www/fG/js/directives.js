angular.module('app.directives', [])

.directive('blankDirective', [function(){

}]);